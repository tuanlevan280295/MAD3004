//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground";

print(str)
print("this is our string: \(str)",terminator: "  ")
//use separartor for saparating mutiple prompts
print("1","2","3","4","5",separator: "..")

var n1=10
print("Number 1: ",n1,"string:",str)

var n2=20
print("Number 2:",str)
 var sum = n1 + n2
print("Sum is: ",sum)
print("Sum = ",n1+n2)

/*
n1 ="test"
 print("n1:",n1)
 */

var a:Int = 10
print("a = ",a)

var great :String = "Good Morning"
print("Greetings :",great)
var emoji = "😁";
print ("its a \(emoji) hour")

let pi = 3.14
//pi = 3.198
print("Pi = ",pi)

//var pi = 10

let myNum:Int? //OPTIONAL
//myNum = 10
myNum = nil
if myNum != nil {
    print("myNum: ",myNum!)
}
else{
    print("myNum is Nil")
}
//optional values
let possibleNumber = "hello" //"hello"
let convertedNumber:Int?

convertedNumber = Int(possibleNumber)

if convertedNumber != nil {
    print("conver Number", convertedNumber!)
}
else{
    print(" converted Numbrt is nil")
}

for i in 1..<5{
    print("1=",i)
}

let languages:[String]
languages = ["English", "Spanish", "French"]

for i in languages{
    print("Language : ",i)
}
//sum
var Anwser: Int = 1
for _ in 1...5{
    print(Anwser += 5)
}

//stride
/*
var Interval:Int = 5
for i in stride(from: 0, to: 50, by: Interval){
    print(i,"  ",terminator:"  ")
}
*/


var j = 1

while ( j < 5 ){
    print("Value of  is \(j)")
j = j + 1
}
j = 5
repeat {
    print("repeat : ",j)
    j = j + 2

} while (j<=10)

var num1 = 10

switch num1 {
case 100:
print("value of num1 is 100")
case 10,15:
print("value of num1 is either 10 or 15")
case 5: 5
print("value of num is 5")

default:
print("default case")
}
